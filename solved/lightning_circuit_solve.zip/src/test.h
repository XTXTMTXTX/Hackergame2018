bool run_test(r1cs_ppzksnark_proving_key<default_r1cs_ppzksnark_pp>& keypair,

          // These are just for changing behavior
          // for testing purposes:
          bool use_and_instead_of_xor,
          bool swap_r1_r2,
          bool goofy_verification_inputs
    );
